NOTE #1: These files will NOT work correctly on your own computer. You can try to open the html pages, but the links and layout might not display properly. This is normal. You must upload the files to a web server.

NOTE #2: These files only work on an Apache server. Almost all shared hosting plans run Apache (Godaddy, Bluehost, OVH, neostrada.com etc.). Contact us if you do not run Apache.

Installation instructions can be found on: http://www.waybackmachinedownloader.com/en/how-to-download-site-from-wayback-machine/